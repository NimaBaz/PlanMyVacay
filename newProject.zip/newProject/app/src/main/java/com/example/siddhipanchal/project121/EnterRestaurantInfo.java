package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class EnterRestaurantInfo extends AppCompatActivity {

    EditText Rest1;
    EditText Add1;

    EditText Rest2;
    EditText Add2;

    EditText Rest3;
    EditText Add3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_restaurant_info);
        getSupportActionBar().hide();

        Rest1 = findViewById(R.id.rest1);
        Add1 = findViewById(R.id.add1);

        Rest2 = findViewById(R.id.rest2);
        Add2 = findViewById(R.id.add2);

        Rest3 = findViewById(R.id.rest3);
        Add3 = findViewById(R.id.add3);

    }

    public void saveRestR(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("REST1", Rest1.getText().toString());
        editor.putString("ADD1", Add1.getText().toString());
        editor.putString("REST2", Rest2.getText().toString());
        editor.putString("ADD2", Add2.getText().toString());
        editor.putString("REST3", Rest3.getText().toString());
        editor.putString("ADD3", Add3.getText().toString());
        editor.commit();


        Intent intent = new Intent(this, roadtrip_page.class);
        startActivity(intent);
    }
}

package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class enterHotel extends AppCompatActivity {

    EditText hotelName;
    EditText addr;
    EditText checkIN;
    EditText checkOut;
    EditText otherInfo;
    EditText HotelNumF;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_hotel);
        getSupportActionBar().hide();

        hotelName = findViewById(R.id.hotelName);
        addr = findViewById(R.id.address);
        checkIN = findViewById(R.id.checkInDate);
        checkOut = findViewById(R.id.checkOutDate);
        otherInfo = findViewById(R.id.other3);
        HotelNumF = findViewById(R.id.hotelNumF);


    }


    public void saveHotelInfoF(View view) {

        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("HotelNameF", hotelName.getText().toString());
        editor.putString("HotelAddrF", addr.getText().toString());
        editor.putString("CheckInF", checkIN.getText().toString());
        editor.putString("CheckOutF", checkOut.getText().toString());
        editor.putString("HotelOtherF", otherInfo.getText().toString());
        editor.putString("HotelNumF", HotelNumF.getText().toString());
        editor.commit();


        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);
    }
}

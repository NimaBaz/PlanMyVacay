package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class enterHotelRoadTrips extends AppCompatActivity {

    EditText HotelName, HotelAdd, CheckInR, CheckOutR, HotelOtherR, HotelNumR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_hotel_road_trips);
        getSupportActionBar().hide();

        HotelName = findViewById(R.id.hotelNameR);
        HotelAdd = findViewById(R.id.addressR);
        CheckInR = findViewById(R.id.checkinR);
        CheckOutR = findViewById(R.id.checkoutR);
        HotelOtherR = findViewById(R.id.hotelOtherR);
        HotelNumR = findViewById(R.id.hotelNumR);


    }

    public void saveHotelR(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("hotelNameR", HotelName.getText().toString());
        editor.putString("hotelAddR", HotelAdd.getText().toString());
        editor.putString("inR", CheckInR.getText().toString());
        editor.putString("outR", CheckOutR.getText().toString());
        editor.putString("hotelOtherR", HotelOtherR.getText().toString());
        editor.putString("HotelNumR", HotelNumR.getText().toString());
        editor.commit();


        Intent intent = new Intent(this, roadtrip_page.class);
        startActivity(intent);
    }
}

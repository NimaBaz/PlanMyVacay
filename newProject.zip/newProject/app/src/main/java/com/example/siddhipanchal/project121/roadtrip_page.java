package com.example.siddhipanchal.project121;



import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class roadtrip_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roadtrip_page);
        getSupportActionBar().hide();
    }

    public void List(View view) {
        Intent intent = new Intent(this, CheckList.class);
        startActivity(intent);
    }
    public void Hotel(View view) {
        Intent intent = new Intent(this, enterHotelRoadTrips.class);
        startActivity(intent);
    }

    public void Destination(View view) {
        Intent intent = new Intent(this, enterRoadInfo.class);
        startActivity(intent);
    }

    public void Excursion(View view) {
        Intent intent = new Intent(this, enterExcursionsRoad.class);
        startActivity(intent);
    }

    public void Restaurant(View view) {
        Intent intent = new Intent(this, EnterRestaurantInfo.class);
        startActivity(intent);
    }

    public void saveTripNameR(View view) {
        Intent intent = new Intent(this, EnterTripNameR.class);
        startActivity(intent);
    }

    public void goToNotesR(View view) {
        Intent intent = new Intent(this, NotesRoad.class);
        startActivity(intent);
    }

    public void goBackHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}

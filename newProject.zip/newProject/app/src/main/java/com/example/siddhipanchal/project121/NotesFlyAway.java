package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class NotesFlyAway extends AppCompatActivity {
    EditText notes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes_fly_away);
        getSupportActionBar().hide();
        notes = findViewById(R.id.notesF);
    }

    public void saveNotesF(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("NotesFlyAway", notes.getText().toString());

        editor.commit();


        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);
    }
}

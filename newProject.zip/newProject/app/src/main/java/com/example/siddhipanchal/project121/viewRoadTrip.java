package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class viewRoadTrip extends AppCompatActivity {

    public static String DEFAULT = "N/A";

    TextView showTripNameR;
    TextView showDes, showStop1, showStop2, showStop3, showOtherR;
    TextView showHotelNameR, showHotelAddR, showHotelNumR, showCheckinR, showCheckoutR, showHotelOtherR;
    TextView showE1, showD1, showT1, showE2, showD2, showT2, showE3, showD3, showT3;
    TextView showRest1, showAdd1, showRest2, showAdd2, showRest3, showAdd3;
    TextView showNoteR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_road_trip);

        //initializations
        showTripNameR = findViewById(R.id.displayTripNameR);

        showDes = findViewById(R.id.displayDes);
        showStop1 = findViewById(R.id.displayStop1);
        showStop2 = findViewById(R.id.displayStop2);
        showStop3 = findViewById(R.id.displayStop3);
        showOtherR = findViewById(R.id.displayOtherDes);

        showHotelNameR = findViewById(R.id.displayHotelNameR);
        showHotelAddR = findViewById(R.id.displayHotelAddR);
        showCheckinR = findViewById(R.id.displaycheckInR);
        showCheckoutR = findViewById(R.id.displaycheckoutR);
        showHotelOtherR = findViewById(R.id.displayHotelOtherR);
        showHotelNumR = findViewById(R.id.displayNumR);

        showE1 = findViewById(R.id.displayEx1);
        showD1 = findViewById(R.id.displayDate1);
        showT1 = findViewById(R.id.displayTime1);
        showE2 = findViewById(R.id.displayEx2);
        showD2 = findViewById(R.id.displayDate2);
        showT2 = findViewById(R.id.displayTime2);
        showE3 = findViewById(R.id.displayEx3);
        showD3 = findViewById(R.id.displayDate3);
        showT3 = findViewById(R.id.displayTime3);

        showRest1 = findViewById(R.id.displayRest1);
        showAdd1 = findViewById(R.id.displayAdd1);
        showRest2 = findViewById(R.id.displayRest2);
        showAdd2 = findViewById(R.id.displayAdd2);
        showRest3 = findViewById(R.id.displayRest3);
        showAdd3 = findViewById(R.id.displayAdd3);

        showNoteR = findViewById(R.id.displayNotesR);

        //Shared Preferences
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);

        String TripNameRoad = sharedPreferences.getString("TripNameR", DEFAULT);

        String Destination = sharedPreferences.getString("Destination", DEFAULT);
        String Stop1 = sharedPreferences.getString("stop1", DEFAULT);
        String Stop2 = sharedPreferences.getString("stop2", DEFAULT);
        String Stop3 = sharedPreferences.getString("stop3", DEFAULT);
        String DesOther = sharedPreferences.getString("InfoOtherR", DEFAULT);

        String HotelNameR = sharedPreferences.getString("hotelNameR", DEFAULT);
        String HotelAddR = sharedPreferences.getString("hotelAddR", DEFAULT);
        String checkInR = sharedPreferences.getString("inR", DEFAULT);
        String checkOutR = sharedPreferences.getString("outR", DEFAULT);
        String hotelOtherR = sharedPreferences.getString("hotelOtherR", DEFAULT);
        String hotelNumR = sharedPreferences.getString("HotelNumR", DEFAULT);

        String E1 = sharedPreferences.getString("E1", DEFAULT);
        String D1 = sharedPreferences.getString("D1", DEFAULT);
        String T1 = sharedPreferences.getString("T1", DEFAULT);
        String E2 = sharedPreferences.getString("E2", DEFAULT);
        String D2 = sharedPreferences.getString("D2", DEFAULT);
        String T2 = sharedPreferences.getString("T2", DEFAULT);
        String E3 = sharedPreferences.getString("E3", DEFAULT);
        String D3 = sharedPreferences.getString("D3", DEFAULT);
        String T3 = sharedPreferences.getString("T3", DEFAULT);

        String Rest1 = sharedPreferences.getString("REST1", DEFAULT);
        String Add1 = sharedPreferences.getString("ADD1", DEFAULT);
        String Rest2 = sharedPreferences.getString("REST2", DEFAULT);
        String Add2 = sharedPreferences.getString("ADD2", DEFAULT);
        String Rest3 = sharedPreferences.getString("REST3", DEFAULT);
        String Add3 = sharedPreferences.getString("ADD3", DEFAULT);

        String NoteR = sharedPreferences.getString("NoteRoad", DEFAULT);

        //set Text Views
        showTripNameR.setText(TripNameRoad);

        showDes.setText(Destination);
        showStop1.setText(Stop1);
        showStop2.setText(Stop2);
        showStop3.setText(Stop3);
        showOtherR.setText(DesOther);

        showHotelNameR.setText(HotelNameR);
        showHotelAddR.setText(HotelAddR);
        showCheckinR.setText(checkInR);
        showCheckoutR.setText(checkOutR);
        showHotelOtherR.setText(hotelOtherR);
        showHotelNumR.setText(hotelNumR);

        showE1.setText(E1);
        showD1.setText(D1);
        showT1.setText(T1);

        showE2.setText(E2);
        showD2.setText(D2);
        showT2.setText(T2);

        showE3.setText(E3);
        showD3.setText(D3);
        showT3.setText(T3);

        showRest1.setText(Rest1);
        showAdd1.setText(Add1);
        showRest2.setText(Rest2);
        showAdd2.setText(Add2);
        showRest3.setText(Rest3);
        showAdd3.setText(Add3);

        showNoteR.setText(NoteR);
    }

    public void findDes(View view) {

        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String Des = sharedPreferences.getString("Destination", DEFAULT);

        if(Des == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + Des));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findStop1(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String S1 = sharedPreferences.getString("stop1", DEFAULT);

        if(S1 == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + S1));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findStop2(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String S2 = sharedPreferences.getString("stop2", DEFAULT);
        if(S2 == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + S2));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findStop3(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String S3 = sharedPreferences.getString("stop3", DEFAULT);

        if(S3 == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + S3));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findStopOther(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String So = sharedPreferences.getString("InfoOtherR", DEFAULT);
        if(So == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + So));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findHotelAddR(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String HA = sharedPreferences.getString("hotelAddR", DEFAULT);
        if(HA == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + HA));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }

    }

    public void findRest1(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String A1 = sharedPreferences.getString("ADD1", DEFAULT);
        if(A1 == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + A1));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findRest2(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String A2 = sharedPreferences.getString("ADD2", DEFAULT);
        if(A2 == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + A2));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void findRest3(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String A3 = sharedPreferences.getString("ADD3", DEFAULT);
        if(A3 == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + A3));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void makeCallR(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String numR = sharedPreferences.getString("HotelNumR", DEFAULT);

        if(numR == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);

        }else{
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData( Uri.parse("tel:" + numR));
            chooser = Intent.createChooser(intent, "Launch Phone");
            startActivity(chooser);
        }
    }
}

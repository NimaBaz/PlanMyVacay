package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class enterExcursionsRoad extends AppCompatActivity {

    EditText ex1, date1, time1, ex2, date2, time2, ex3, date3, time3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_excursions_road);
        getSupportActionBar().hide();

        ex1 = findViewById(R.id.EX1);
        date1 = findViewById(R.id.D1);
        time1 = findViewById(R.id.T1);
        ex2 = findViewById(R.id.EX2);
        date2 = findViewById(R.id.D2);
        time2 = findViewById(R.id.T2);
        ex3 = findViewById(R.id.EX3);
        date3 = findViewById(R.id.D3);
        time3 = findViewById(R.id.T3);
    }

    public void saveExcursionsR(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("E1", ex1.getText().toString());
        editor.putString("D1", date1.getText().toString());
        editor.putString("T1", time1.getText().toString());

        editor.putString("E2", ex2.getText().toString());
        editor.putString("D2", date2.getText().toString());
        editor.putString("T2", time2.getText().toString());

        editor.putString("E3", ex3.getText().toString());
        editor.putString("D3", date3.getText().toString());
        editor.putString("T3", time3.getText().toString());

        editor.commit();

        Intent intent = new Intent(this, roadtrip_page.class);
        startActivity(intent);

    }
}

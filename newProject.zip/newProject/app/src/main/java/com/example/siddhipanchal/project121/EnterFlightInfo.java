package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EnterFlightInfo extends AppCompatActivity {

    EditText flightNum;
    EditText checkTime;
    EditText takeTime;
    EditText airFrom;
    EditText airTo;
    File folder;
    String path;
    FileWriter outFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_flight_info);
        getSupportActionBar().hide();

        //Get the id and set it to variables
        flightNum = findViewById(R.id.flightNumber);
        checkTime = findViewById(R.id.checkInTime);
        takeTime = findViewById(R.id.takeOffTime);
        airFrom = findViewById(R.id.airportFrom);
        airTo = findViewById(R.id.airportTo);

        //create a folder into internal storage
        //rename the string at the end for the folder name
        folder = new File(String.valueOf(getFilesDir()) + "/Plane Trip");
        if (!folder.exists()) {
            folder.mkdir();
        }

        //pathing into the folder
        path = String.valueOf(getFilesDir()) +  "/Plane Trip/";
    }

    public void done(View view) {

        //turn the edit text inputs into String
        String fnum = flightNum.getText().toString();
        String ctime = checkTime.getText().toString();
        String ttime = takeTime.getText().toString();
        String afrom = airFrom.getText().toString();
        String aTo = airTo.getText().toString();

        //Save all the strings into a text file name after whatever
        try {
            //naming the text file
            outFile =  new FileWriter(path + fnum);

            //put string into the text file
            outFile.write(fnum + "\n");
            outFile.write(ctime + "\n");
            outFile.write(ttime + "\n");
            outFile.write(afrom + "\n");
            outFile.write(aTo + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

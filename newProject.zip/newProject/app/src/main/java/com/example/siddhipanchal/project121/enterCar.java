package com.example.siddhipanchal.project121;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class enterCar extends AppCompatActivity {

    EditText carCompanyF;
    EditText resTimeF;
    EditText carPrefF;
    EditText otherInfoF;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_car);
        getSupportActionBar().hide();

        carCompanyF = findViewById(R.id.carrental);
        resTimeF = findViewById(R.id.reservation);
        carPrefF = findViewById(R.id.preference);
        otherInfoF = findViewById(R.id.other);

    }




    public void saveCarInfoFlight(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("CarCompanyF", carCompanyF.getText().toString());
        editor.putString("ResTimeF", resTimeF.getText().toString());
        editor.putString("CarPrefF", carPrefF.getText().toString());
        editor.putString("OtherInfoF", otherInfoF.getText().toString());
        editor.commit();


        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);

    }
}

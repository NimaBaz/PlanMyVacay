package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class EnterDestination extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_destination);
        getSupportActionBar().hide();
    }

    public void done(View view) {
    }
}

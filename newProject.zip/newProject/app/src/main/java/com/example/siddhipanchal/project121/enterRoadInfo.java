package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class enterRoadInfo extends AppCompatActivity {
    EditText Des;

    EditText wait1;
    EditText wait2;
    EditText wait3;
    EditText otherInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_road_info);
        getSupportActionBar().hide();

        Des = findViewById(R.id.destination);
        wait1 = findViewById(R.id.stop1);
        wait2 = findViewById(R.id.stop2);
        wait3 = findViewById(R.id.stop3);
        otherInfo = findViewById(R.id.desOtherR);

    }

    public void saveDestinationInfo(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Destination", Des.getText().toString());
        editor.putString("stop1", wait1.getText().toString());
        editor.putString("stop2", wait2.getText().toString());
        editor.putString("stop3", wait3.getText().toString());
        editor.putString("InfoOtherR", otherInfo.getText().toString());
        editor.commit();


        Intent intent = new Intent(this, roadtrip_page.class);
        startActivity(intent);

    }
}

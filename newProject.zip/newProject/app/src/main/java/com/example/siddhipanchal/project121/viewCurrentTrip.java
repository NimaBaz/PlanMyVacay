package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class viewCurrentTrip extends AppCompatActivity {


    public ListView info;
    public MyCustomAdapter listInfoAdapter;

    public FileWriter infoFile;
    public File infodirectory;

    //Context context = getApplicationContext();
   // String files = "files.txt";
   // String str = viewTrip(context, files);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_current_trip);
        getSupportActionBar().hide();

        info = (ListView) findViewById(R.id.info);


    }

    public void goToChecklist(View view) {
        Intent intent = new Intent(this, CheckList.class);
        startActivity(intent);
    }

    public String viewTrip(Context context, String files) {
        try {
            FileInputStream fis = context.openFileInput(files);
            InputStreamReader isr = new InputStreamReader(fis, "UTF-8");
            BufferedReader bufferedReader = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            return sb.toString();
        } catch (FileNotFoundException e) {
            return "";
        } catch (UnsupportedEncodingException e) {
            return "";
        } catch (IOException e) {
            return "";
        }


    }
}
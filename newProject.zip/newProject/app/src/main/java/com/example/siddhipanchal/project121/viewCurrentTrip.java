package com.example.siddhipanchal.project121;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class viewCurrentTrip extends AppCompatActivity {

    public ListView info;
    public File folder;
    String path;
    public File[] files;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_current_trip);
        getSupportActionBar().hide();

        info = (ListView) findViewById(R.id.info);

        folder = new File(String.valueOf(getFilesDir()) + "/All Files");
        if (!folder.exists()) {
            folder.mkdir();
        }
        path = String.valueOf(getFilesDir()) + "/All Files";

        if (folder.exists()) {
            files = folder.listFiles();
            for (File file : files) {

                StringBuilder text = new StringBuilder();

                try {

                    //access a file
                    FileInputStream readingFile = new FileInputStream(path + "/" + file.getName());
                    InputStreamReader isr = new InputStreamReader(readingFile, "UTF-8");
                    //reading the input of the file. what in the text file
                    BufferedReader br = new BufferedReader(new FileReader(String.valueOf(isr)));
                    String line;

                    //add the input of file in a stringbuilder
                    while ((line = br.readLine()) != null) {
                        text.append(line);
                        text.append('\n');
                    }
                    /*add code to print it into the screen here*/
                    br.close();
                    String result = text.toString();
                } catch (IOException e) {

                }
            }
            Toast.makeText(this, "Files saved here", Toast.LENGTH_LONG).show();
        }
    }

    public void goToChecklist(View view) {
        Intent intent = new Intent(this, CheckList.class);
        startActivity(intent);
    }
}
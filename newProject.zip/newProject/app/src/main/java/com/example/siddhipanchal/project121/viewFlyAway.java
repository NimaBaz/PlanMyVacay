package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class viewFlyAway extends AppCompatActivity {

    public static String DEFAULT = "N/A";
    TextView ShowTripNameF;
    TextView ShowFlightNum, ShowFlightDate, ShowTakeOff, ShowLandIn, ShowAirFrom, ShowAirTo;
    TextView ShowCarCom, ShowResTime, ShowCarPref, ShowOther;
    TextView ShowHotelName, ShowHotelAddr, ShowHotelNumF, ShowCheckInF, ShowCheckOutF, ShowHotelOtherF;
    TextView ShowEx1F, ShowDate1F, ShowTime1F, ShowEx2F, ShowDate2F, ShowTime2F, ShowEx3F, ShowDate3F, ShowTime3F;
    TextView ShowNotesF;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_fly_away);


        //initializations
        ShowTripNameF = findViewById(R.id.displayTripNameF);

        ShowFlightNum = findViewById(R.id.displayFlightNum);
        ShowFlightDate = findViewById(R.id.displayFlightDate);
        ShowTakeOff = findViewById(R.id.displayTakeoff);
        ShowLandIn = findViewById(R.id.displayLandin);
        ShowAirFrom = findViewById(R.id.displayAirFrom);
        ShowAirTo = findViewById(R.id.displayAirTo);

        ShowCarCom = findViewById(R.id.displayCompany);
        ShowResTime = findViewById(R.id.displayResTime);
        ShowCarPref = findViewById(R.id.displayPref);
        ShowOther = findViewById(R.id.displayOther);

        ShowHotelName = findViewById(R.id.displayHotelNameF);
        ShowHotelAddr = findViewById(R.id.displayHotelAddrF);
        ShowHotelNumF =findViewById(R.id.displayNumF);
        ShowCheckInF = findViewById(R.id.displayCheckInF);
        ShowCheckOutF = findViewById(R.id.displayCheckOutF);
        ShowHotelOtherF = findViewById(R.id.displayHotelOtherF);

        ShowEx1F = findViewById(R.id.displayEx1F);
        ShowDate1F = findViewById(R.id.displayDate1F);
        ShowTime1F = findViewById(R.id.displayTime1F);
        ShowEx2F = findViewById(R.id.displayEx2F);
        ShowDate2F = findViewById(R.id.displayDate2F);
        ShowTime2F = findViewById(R.id.displayTime2F);
        ShowEx3F = findViewById(R.id.displayEx3F);
        ShowDate3F = findViewById(R.id.displayDate3F);
        ShowTime3F = findViewById(R.id.displayTime3F);

        ShowNotesF = findViewById(R.id.displayNotesF);

        //Shared Preferences
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);

        String TripNameFlight = sharedPreferences.getString("TripNameF", DEFAULT);

        String FlightNumber = sharedPreferences.getString("FlightNumber", DEFAULT);
        String FlightDate = sharedPreferences.getString("FlightDate", DEFAULT);
        String TakeoffTime = sharedPreferences.getString("TakeOffTime", DEFAULT);
        String LandTime = sharedPreferences.getString("LandingIn", DEFAULT);
        String AirportFrom = sharedPreferences.getString("AirportFrom", DEFAULT);
        String AirportTo = sharedPreferences.getString("AirportTo", DEFAULT);

        String CarCompanyF = sharedPreferences.getString("CarCompanyF", DEFAULT);
        String ReservationTimeF = sharedPreferences.getString("ResTimeF", DEFAULT);
        String CarPrefF = sharedPreferences.getString("CarPrefF", DEFAULT);
        String CarOtherF = sharedPreferences.getString("OtherInfoF", DEFAULT);

        String HotelNameF = sharedPreferences.getString("HotelNameF", DEFAULT);
        String HotelAddressF = sharedPreferences.getString("HotelAddrF", DEFAULT);
        String HotelNumF = sharedPreferences.getString("HotelNumF", DEFAULT);
        String HotelCheckInF = sharedPreferences.getString("CheckInF", DEFAULT);
        String HotelCheckOutF = sharedPreferences.getString("CheckOutF", DEFAULT);
        String HotelOtherF = sharedPreferences.getString("HotelOtherF", DEFAULT);

        String Ex1F = sharedPreferences.getString("EX1F", DEFAULT);
        String Data1F = sharedPreferences.getString("Date1F", DEFAULT);
        String Time1F = sharedPreferences.getString("Time1F", DEFAULT);
        String Ex2F = sharedPreferences.getString("EX2F", DEFAULT);
        String Data2F = sharedPreferences.getString("Date2F", DEFAULT);
        String Time2F = sharedPreferences.getString("Time2F", DEFAULT);
        String Ex3F = sharedPreferences.getString("EX3F", DEFAULT);
        String Data3F = sharedPreferences.getString("Date3F", DEFAULT);
        String Time3F = sharedPreferences.getString("Time3F", DEFAULT);

        String NotesF = sharedPreferences.getString("NotesFlyAway", DEFAULT);






        //set Text Views
        ShowTripNameF.setText(TripNameFlight);

        ShowFlightNum.setText(FlightNumber);
        ShowFlightDate.setText(FlightDate);
        ShowTakeOff.setText(TakeoffTime);
        ShowLandIn.setText(LandTime);
        ShowAirFrom.setText(AirportFrom);
        ShowAirTo.setText(AirportTo);

        ShowCarCom.setText(CarCompanyF);
        ShowResTime.setText(ReservationTimeF);
        ShowCarPref.setText(CarPrefF);
        ShowOther.setText(CarOtherF);

        ShowHotelName.setText(HotelNameF);
        ShowHotelAddr.setText(HotelAddressF);
        ShowHotelNumF.setText(HotelNumF);
        ShowCheckInF.setText(HotelCheckInF);
        ShowCheckOutF.setText(HotelCheckOutF);
        ShowHotelOtherF.setText(HotelOtherF);

        ShowEx1F.setText(Ex1F);
        ShowDate1F.setText(Data1F);
        ShowTime1F.setText(Time1F);
        ShowEx2F.setText(Ex2F);
        ShowDate2F.setText(Data2F);
        ShowTime2F.setText(Time2F);
        ShowEx3F.setText(Ex3F);
        ShowDate3F.setText(Data3F);
        ShowTime3F.setText(Time3F);

        ShowNotesF.setText(NotesF);


    }

    public void findHotelAddFlight(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String Hadd = sharedPreferences.getString("HotelAddrF", DEFAULT);
        if(Hadd == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);
        }else {
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("geo:0,0?q=" + Hadd));
            chooser = Intent.createChooser(intent, "Launch Maps");
            startActivity(chooser);
        }
    }

    public void makeCallF(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        String numF = sharedPreferences.getString("HotelNumF", DEFAULT);

        if(numF == null){
            Intent i = new Intent(this, viewRoadTrip.class);

            startActivity(i);

        }else{
            Intent chooser = null;
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData( Uri.parse("tel:" + numF));
            chooser = Intent.createChooser(intent, "Launch Phone");
            startActivity(chooser);
        }

    }
}

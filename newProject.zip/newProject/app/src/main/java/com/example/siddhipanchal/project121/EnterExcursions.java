package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EnterExcursions extends AppCompatActivity {
    EditText excur1;
    EditText time1;
    EditText date1;
    EditText excur2;
    EditText time2;
    EditText date2;
    EditText excur3;
    EditText time3;
    EditText date3;
    File folder;
    String path;
    FileWriter outFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_excursions);
        getSupportActionBar().hide();

        excur1 = findViewById(R.id.excursion1);
        date1 = findViewById(R.id.excur1Date);
        time1 = findViewById(R.id.excur1Time);
        excur2 = findViewById(R.id.excursion2);
        date2 = findViewById(R.id.excur2Date);
        time2 = findViewById(R.id.excur2Time);
        excur3 = findViewById(R.id.excursion3);
        date3 = findViewById(R.id.excur3Date);
        time3 = findViewById(R.id.excur3Time);

        folder = new File(String.valueOf(getFilesDir()) + "/Excursions");
        if (!folder.exists()) {
            folder.mkdir();
        }
        path = String.valueOf(getFilesDir()) +  "/Excursions/";
    }

    public void done(View view) {
        String activity1 = excur1.getText().toString();
        String d1 = date1.getText().toString();
        String t1 = time1.getText().toString();
        String activity2 = excur2.getText().toString();
        String d2 = date2.getText().toString();
        String t2 = time2.getText().toString();
        String activity3 = excur3.getText().toString();
        String d3 = date3.getText().toString();
        String t3 = time3.getText().toString();

        try {
            outFile =  new FileWriter(path + activity1);
            outFile.write(activity1 + "\n");
            outFile.write(d1 + "\n");
            outFile.write(t1 + "\n");
            outFile.write(activity2 + "\n");
            outFile.write(d2 + "\n");
            outFile.write(t2 + "\n");
            outFile.write(activity3 + "\n");
            outFile.write(d3 + "\n");
            outFile.write(t3 + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

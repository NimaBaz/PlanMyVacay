package com.example.siddhipanchal.project121;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.ArrayList;

class RestaurantAdapter extends BaseAdapter implements ListAdapter {
    private ArrayList<String> listRow = new ArrayList<String>();
    private Context context;

    public RestaurantAdapter(ArrayList<String> listRow, Context context){
        this.listRow = listRow;
        this.context = context;
    }
    @Override
    public int getCount() {
        return listRow.size();
    }

    @Override
    public Object getItem(int i) {
        return listRow.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.restrow, null);
        }

        TextView restView = view.findViewById(R.id.restText);
        //TextView addrView = view.findViewById(R.id.addrText);
        restView.setText(listRow.get(i));
        //addrView.setText(listRow.get(i));

        return view;
    }


}

package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class enterTripNameF extends AppCompatActivity {

    //MyDB db;
    static EditText tripNameFlight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_trip_name_f);
        getSupportActionBar().hide();
        tripNameFlight = findViewById(R.id.enterTripName);
        //db = new MyDB(this, "pmv", null, 1);
    }

    public void saveNameF(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("TripNameF", tripNameFlight.getText().toString());
        editor.commit();




        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);
    }

    /*public void insertName(View view) {
        String s1 = tripNameFlight.getText().toString();
        db.insert(s1);
        if(tripNameFlight.getText().toString().trim().length() == 0){
            Toast.makeText(this, "No Trip Name was entered", Toast.LENGTH_LONG).show();
        }
        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);
    }*/
}

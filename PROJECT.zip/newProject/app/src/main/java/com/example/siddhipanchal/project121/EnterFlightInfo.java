package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EnterFlightInfo extends AppCompatActivity {
    //MyDB db;

    static EditText flightNum;
    static EditText takeOff;
    static EditText landIn;
    static EditText airFrom;
    static EditText airTo;
    static EditText dateFlight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_flight_info);
        getSupportActionBar().hide();

        //initialize the database
        //db = new MyDB(this, "pmv", null, 1);

        //Get the id and set it to variables
        flightNum = findViewById(R.id.flightNumber);
        takeOff = findViewById(R.id.TakeoffTime);
        landIn = findViewById(R.id.landingTime);
        airFrom = findViewById(R.id.airportFrom);
        airTo = findViewById(R.id.airportTo);
        dateFlight = findViewById(R.id.dateFlight);
    }

    public void saveFlightInfo(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("FlightNumber", flightNum.getText().toString());
        editor.putString("TakeOffTime", takeOff.getText().toString());
        editor.putString("LandingIn", landIn.getText().toString());
        editor.putString("AirportFrom", airFrom.getText().toString());
        editor.putString("AirportTo", airTo.getText().toString());
        editor.putString("FlightDate", dateFlight.getText().toString());
        editor.commit();


        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);
    }

    /*public void insertFlightInfo(View view) {
        String s1 = flightNum.getText().toString();
        String s2 = takeOff.getText().toString();
        String s3 = landIn.getText().toString();
        String s4 = airFrom.getText().toString();
        String s5 = airTo.getText().toString();
        db.insert1(s1, s2, s3, s4, s5);
        if(flightNum.getText().toString().trim().length() == 0){
            Toast.makeText(this, "No Flight Number was entered", Toast.LENGTH_LONG).show();
        }
        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);

    }*/




}

package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class CheckList extends AppCompatActivity {

    public File directory;
    public File[] files;
    public Button addButton;
    public Button editButton;
    public EditText itemText;
    public ListView listItem;
    public ArrayList<Item> listing = new ArrayList<Item>();
    public MyCustomAdapter adapter;
    public String path;
    public FileWriter outfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_list);


        addButton = findViewById(R.id.adding);
        editButton = findViewById(R.id.editing);
        itemText = findViewById(R.id.editText);
        listItem = findViewById(R.id.itemListing);

        path =  String.valueOf(getFilesDir()) + "/CheckList";
        directory = new File(String.valueOf(getFilesDir()) + "/CheckList");
        if(!directory.exists()) {
            directory.mkdir();
        }
        if(directory.exists()) {
            files = directory.listFiles();
            for(File file: files) {
                boolean checkState = false;
                try {
                    Log.e("reach", "try");
                    BufferedReader br = new BufferedReader(new FileReader(path + "/" + file.getName()));
                    String line;
                    while((line = br.readLine()) != null) {
                        Log.e("reach", "while");
                        checkState = !line.equals("false");
                    }

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Item item = new Item(file.getName(), checkState);
                listing.add(item);
            }
        }
        adapter = new MyCustomAdapter(this, R.layout.item, listing);
        listItem.setAdapter(adapter);

    }

    public void add(View view) {
        String text = itemText.getText().toString();
        Item addItem = new Item(text, false);
        listing.add(addItem);

        //code to add to sharedpref here
        try {
            outfile = new FileWriter(path + "/" + text);
            outfile.write("false");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outfile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Toast.makeText(this, "item" + listing.get(0), Toast.LENGTH_LONG).show();
        adapter = new MyCustomAdapter(this, R.layout.item, listing);
        listItem.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void update(ArrayList<Item> listing, String tempt) {
        this.listing = listing;
        adapter = new MyCustomAdapter(this, R.layout.item, listing);
        listItem.setAdapter(adapter);
        deleteFile(tempt);
        adapter.notifyDataSetChanged();
    }

    public void set(View view) {
        Intent intent = new Intent(this, SetReminder.class);
        startActivity(intent);
    }

    private class MyCustomAdapter extends ArrayAdapter<Item> {

        private ArrayList<Item> listing;

        MyCustomAdapter(Context context, int itemID, ArrayList<Item> listing) {
            super(context, itemID, listing);
            this.listing = new ArrayList<Item>();
            this.listing.addAll(listing);
        }

        private class ViewHolder {
            CheckBox checkBox;
            Button deleteButton;
        }

        @Override
        public View getView(final int position, View view, ViewGroup viewGroup) {
            //Toast.makeText(getContext(), "here ", Toast.LENGTH_LONG).show();
            ViewHolder holder = null;

            if(view  == null) {
                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = vi.inflate(R.layout.item, null);

                holder = new ViewHolder();

                holder.checkBox = view.findViewById(R.id.check);
                holder.deleteButton = view.findViewById(R.id.button);
                view.setTag(holder);
            } else {
                holder = (ViewHolder) view.getTag();
            }
            Item item = listing.get(position);

            holder.checkBox.setText(item.getItem());
            holder.checkBox.setChecked(item.isSelect());
            holder.checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox check = (CheckBox) v;
                    Item item = (Item) check.getTag();
                    boolean checked = item.isSelect();
                    String tempt = item.getItem();
                    item.setSelect(!checked);
                    try {
                        outfile = new FileWriter(path + "/" + tempt);
                        outfile.write(String.valueOf(!checked));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        outfile.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    //code to change the value in the sharedpref here
                    //value being false to true or true to false
                }
            });

            holder.deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox check = (CheckBox) v;
                    Item item = (Item) check.getTag();
                    String tempt = item.getItem();
                    listing.remove(position);

                    //code to remove a sharedpref here

                    update(listing, tempt);
                }
            });
            holder.deleteButton.setTag(item);
            holder.checkBox.setTag(item);
            return view;
        }
    }
}
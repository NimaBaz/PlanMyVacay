package com.example.siddhipanchal.project121;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import static com.example.siddhipanchal.project121.SetReminder.message;
import static com.example.siddhipanchal.project121.SetReminder.title;

public class alarmItems extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationHelper notificationHelper = new NotificationHelper(context);
        NotificationCompat.Builder builder = notificationHelper.getChannelNotification(title, message);
        notificationHelper.getManager().notify(0, builder.build());
    }
}

package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
    }

    public void make_new(View view) {
        Intent intent = new Intent(this, ChooseTemplate.class);
        startActivity(intent);
    }

    public void goToViewTrip(View view) {
        Intent intent = new Intent(this, viewCurrentTrip.class);
        startActivity(intent);
    }
}

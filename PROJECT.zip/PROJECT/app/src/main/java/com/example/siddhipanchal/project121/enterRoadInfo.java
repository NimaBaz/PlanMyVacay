package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class enterRoadInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_road_info);
    }
}

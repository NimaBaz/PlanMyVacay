package com.example.siddhipanchal.project121;



import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class roadtrip_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_roadtrip_page);
    }

    public void Hotel(View view) {
        Intent intent = new Intent(this, enterHotel.class);
        startActivity(intent);
    }

    public void Destination(View view) {
        Intent intent = new Intent(this, enterRoadInfo.class);
        startActivity(intent);
    }

    public void Excursion(View view) {
        Intent intent = new Intent(this, EnterExcursions.class);
        startActivity(intent);
    }

    public void Restaurant(View view) {
        Intent intent = new Intent(this, EnterRestaurantInfo.class);
        startActivity(intent);
    }

}

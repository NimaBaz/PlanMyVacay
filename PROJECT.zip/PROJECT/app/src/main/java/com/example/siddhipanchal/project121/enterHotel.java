package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class enterHotel extends AppCompatActivity {
    EditText hotelNum;
    EditText phoneNum;
    EditText addr;
    EditText checkIN;
    EditText checkinTime;
    EditText checkOut;
    EditText checkoutTime;
    EditText otherInfo;
    File folder;
    String path;
    FileWriter outFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_hotel);

        hotelNum = findViewById(R.id.hotelName);
        phoneNum = findViewById(R.id.phoneNum);
        addr = findViewById(R.id.address);
        checkIN = findViewById(R.id.checkInDate);
        checkinTime = findViewById(R.id.checkInHotel);
        checkOut = findViewById(R.id.checkOutDate);
        checkoutTime = findViewById(R.id.checkOutHotel);
        otherInfo = findViewById(R.id.other3);

        folder = new File(String.valueOf(getFilesDir()) + "/Hotel");
        if (!folder.exists()) {
            folder.mkdir();
        }
        path = String.valueOf(getFilesDir()) +  "/Hotel/";
    }


    public void done(View view) {
        String hNum = hotelNum.getText().toString();
        String pNum = phoneNum.getText().toString();
        String location = addr.getText().toString();
        String ckIn = checkIN.getText().toString();
        String ckInT = checkinTime.getText().toString();
        String ckOut = checkOut.getText().toString();
        String ckOutT = checkoutTime.getText().toString();
        String other = otherInfo.getText().toString();

        try {
            outFile =  new FileWriter(path + hNum);
            outFile.write(hNum + "\n");
            outFile.write(pNum + "\n");
            outFile.write(location + "\n");
            outFile.write(ckIn + "\n");
            outFile.write(ckInT + "\n");
            outFile.write(ckOut + "\n");
            outFile.write(ckOutT + "\n");
            outFile.write(other + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

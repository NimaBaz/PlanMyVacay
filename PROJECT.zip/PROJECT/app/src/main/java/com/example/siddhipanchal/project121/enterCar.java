package com.example.siddhipanchal.project121;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class enterCar extends AppCompatActivity {

    EditText carCompany;
    EditText resTime;
    EditText carPref;
    EditText otherInfo;
    File folder;
    String path;
    FileWriter outFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_car);

        carCompany = findViewById(R.id.carrental);
        resTime = findViewById(R.id.reservation);
        carPref = findViewById(R.id.preference);
        otherInfo = findViewById(R.id.other);

        folder = new File(String.valueOf(getFilesDir()) + "/Car Rental");
        if (!folder.exists()) {
            folder.mkdir();
        }
        path = String.valueOf(getFilesDir()) +  "/Car Rental/";

    }

    public void done(View view) {
        String ccompany = carCompany.getText().toString();
        String rtime = resTime.getText().toString();
        String cpref = carPref.getText().toString();
        String oinfo = otherInfo.getText().toString();

        try {
            outFile =  new FileWriter(path + ccompany);
            outFile.write(ccompany + "\n");
            outFile.write(rtime + "\n");
            outFile.write(cpref + "\n");
            outFile.write(oinfo + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

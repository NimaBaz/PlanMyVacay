package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class Flights_Page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flights__page);
    }

    public void Trip(View view) {
    }

    public void List(View view) {
    }

    public void Flight(View view) {
        Intent intent = new Intent(this, EnterFlightInfo.class);
        startActivity(intent);
    }

    public void Rental(View view) {
        Intent intent = new Intent(this, enterCar.class);
        startActivity(intent);
    }

    public void Hotel(View view) {
        Intent intent = new Intent(this, enterHotel.class);
        startActivity(intent);
    }

    public void Excursion(View view) {
        Intent intent = new Intent(this, EnterExcursions.class);
        startActivity(intent);
    }

    public void Restaurant(View view) {
        Intent intent = new Intent(this, EnterRestaurantInfo.class);
        startActivity(intent);
    }

}

package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class ChooseTemplate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_template);
    }

    public void roadTrip(View view) {
        Intent intent = new Intent(this, roadtrip_page.class);
        startActivity(intent);

    }

    public void flight(View view) {
        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);

    }
}

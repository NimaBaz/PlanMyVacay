package com.example.siddhipanchal.project121;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class CheckList extends AppCompatActivity implements View.OnClickListener {

    Intent intent;

    //Global variables
    public Button button;
    public ListView mainList;
    public MyCustomAdapter listAdapter;
    public FileWriter outFile;
    public File directory;
    //public File outFile;
    public File[] files;
    public ArrayList<String> itemList;
    public EditText itemText;
    public boolean clear;
    public int duplicateCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_list);
        intent = getIntent();

        clear = false;

        //Layout setting
        mainList = (ListView) findViewById(R.id.itemListing);
        itemList = new ArrayList<String>();
        listAdapter = new MyCustomAdapter(itemList, this);

        //Internal storage load out
        directory = new File(String.valueOf(getFilesDir()) + "/Check List");
        if (!directory.exists()) {
            directory.mkdir();
        }

        if (directory.exists()) {
        files = directory.listFiles();
            for (File file : files) {
                itemList.add(file.getName());
            }
        }

        itemText = (EditText) findViewById(R.id.itemList);
        itemText.setOnClickListener(this);

        mainList.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }

    //Add new item to the scrollList and the save xml file
    public void addItem(View view) {
        String addingItem = itemText.getText().toString(); //Get the string
        clear = false;

        //Check for duplicate list item
        //Add more number to keep count of the item
        duplicateCount = 0;
        String tempt = addingItem;
        while(itemList.contains(addingItem)){
            duplicateCount++;
            addingItem = tempt + "_" + String.valueOf(duplicateCount);
        }

        itemList.add(addingItem);
        mainList.setAdapter(listAdapter);

        //Save to internal storage
        //Assume someone not gonna save the same thing twice
        //outFile = openFileOutput(addingItem, MODE_PRIVATE);
        try {
            outFile = new FileWriter(String.valueOf(getFilesDir()) + "/Check List/" + addingItem);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        itemText.setText("Item");
    }

    @Override
    public void onClick(View view) {
        if(clear == false){
            clear = true;
            itemText.getText().clear();
        }
    }
}
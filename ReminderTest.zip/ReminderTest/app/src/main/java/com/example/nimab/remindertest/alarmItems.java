package com.example.nimab.remindertest;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;

public class alarmItems extends BroadcastReceiver {

    int notificationId;
    String message;
    Intent mainIntent;
    PendingIntent contentIntent;
    NotificationManager myNotificationManager;
    Notification.Builder builder;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onReceive(Context context, Intent intent) {
        notificationId = intent.getIntExtra("notificationId", 0);
        message = intent.getStringExtra("todo");

        mainIntent = new Intent(context, MainActivity.class);
        contentIntent = PendingIntent.getActivity(context, 0, mainIntent, 0);
        myNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        builder = new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Yoooooooooo!")
                .setContentText(message)
                .setWhen(System.currentTimeMillis())
                .setAutoCancel(true)
                .setContentIntent(contentIntent)
                .setPriority(Notification.PRIORITY_MAX)
                .setDefaults(Notification.DEFAULT_ALL);

        myNotificationManager.notify(notificationId, builder.build());
    }
}

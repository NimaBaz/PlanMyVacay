package com.example.planmyvacay;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;


public class CheckList extends AppCompatActivity {

    Intent intent;

    //Global variables
    public Button button;
    public ListView mainList;
    public ArrayAdapter<String> listAdapter;
    public FileOutputStream outFile;
    public File directory;
    public File[] files;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_list);
        intent = getIntent();

        //Layout setting
        mainList = (ListView) findViewById(R.id.itemListing);
        ArrayList<String> itemList = new ArrayList<String>();
        listAdapter = new ArrayAdapter<String>(this, R.layout.simplerow, itemList);

        //Internal storage load out
        directory = new File(String.valueOf(getFilesDir()));

        if (directory.exists()) {
        files = directory.listFiles();
            for (File file : files) {
                listAdapter.add(file.getName());
            }
        }

        mainList.setAdapter(listAdapter);

        mainList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id) {
                String selectedItem = (String) mainList.getItemAtPosition(i);
                Toast.makeText(CheckList.this, "number" + i, Toast.LENGTH_SHORT).show();
                listAdapter.remove(selectedItem);
                deleteFile(selectedItem);
                listAdapter.notifyDataSetChanged();
            }
        });
    }

    //Add new item to the scrollList and the save xml file
    public void addItem(View view) {
        EditText itemText = (EditText) findViewById(R.id.itemList);
        String addingItem = itemText.getText().toString(); //Get the string
        listAdapter.add(addingItem);
        mainList.setAdapter(listAdapter);

        //Save to internal storage
        //Assume someone not gonna save the same thing twice
        try {
            outFile = openFileOutput(addingItem, MODE_PRIVATE);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (outFile != null) {
                try {
                    outFile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
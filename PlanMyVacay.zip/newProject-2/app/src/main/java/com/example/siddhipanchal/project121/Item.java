package com.example.siddhipanchal.project121;

public class Item {
    String item = null;
    boolean select = false;

    public Item(String item, boolean select) {
        super();
        this.item = item;
        this.select = select;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public boolean isSelect() {
        return select;
    }

    public void setSelect(boolean select) {
        this.select = select;
    }
}
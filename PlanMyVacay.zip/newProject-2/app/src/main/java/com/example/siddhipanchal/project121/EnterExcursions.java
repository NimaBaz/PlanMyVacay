package com.example.siddhipanchal.project121;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EnterExcursions extends AppCompatActivity {
    EditText excur1;
    EditText time1;
    EditText date1;

    EditText excur2;
    EditText time2;
    EditText date2;

    EditText excur3;
    EditText time3;
    EditText date3;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_excursions);
        getSupportActionBar().hide();

        excur1 = findViewById(R.id.excursion1);
        date1 = findViewById(R.id.excur1Date);
        time1 = findViewById(R.id.excur1Time);

        excur2 = findViewById(R.id.excursion2);
        date2 = findViewById(R.id.excur2Date);
        time2 = findViewById(R.id.excur2Time);

        excur3 = findViewById(R.id.excursion3);
        date3 = findViewById(R.id.excur3Date);
        time3 = findViewById(R.id.excur3Time);


    }


    public void saveExcursionsF(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences("mydata", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("EX1F", excur1.getText().toString());
        editor.putString("Date1F", date1.getText().toString());
        editor.putString("Time1F", time1.getText().toString());
        editor.putString("EX2F", excur2.getText().toString());
        editor.putString("Date2F", date2.getText().toString());
        editor.putString("Time2F", time2.getText().toString());
        editor.putString("EX3F", excur3.getText().toString());
        editor.putString("Date3F", date3.getText().toString());
        editor.putString("Time3F", time3.getText().toString());

        editor.commit();


        Intent intent = new Intent(this, Flights_Page.class);
        startActivity(intent);
    }
}

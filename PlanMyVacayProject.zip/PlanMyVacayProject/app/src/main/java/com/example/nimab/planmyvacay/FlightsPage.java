package com.example.nimab.planmyvacay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FlightsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flights_page);
    }

    public void Trip(View view) {
    }

    public void List(View view) {
    }

    public void Flight(View view) {
    }

    public void Rental(View view) {
    }

    public void Hotel(View view) {
    }

    public void Excursion(View view) {
    }

    public void Restaurant(View view) {
    }

    public void Destination(View view) {
    }
}

package com.example.silve.checklist;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.DateFormat;
import java.util.Calendar;

public class SetReminder extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener, DatePickerDialog.OnDateSetListener {

    public EditText editTextTitle;
    public EditText editTextMessage;
    private TextView textView;
    private TextView mtextView;
    private Button cancel;
    private Button timePicker;
    private Button datePicker;
    public static String title;
    public static String message;
    public static String title2;
    public static String message2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_reminder);

        editTextTitle = findViewById(R.id.edit_text_title);
        editTextMessage = findViewById(R.id.edit_text_message);
        mtextView = findViewById(R.id.textView);
        textView = findViewById(R.id.textView2);

        timePicker = findViewById(R.id.setBtn);
        timePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment time = new TimePickerFragment();
                time.show(getSupportFragmentManager(), "time picker");
                title = editTextTitle.getText().toString();
                message = editTextMessage.getText().toString();
            }
        });

        datePicker = findViewById(R.id.button);
        datePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment date = new DateTimerFragment();
                date.show(getSupportFragmentManager(), "date picker");
                title2 = editTextTitle.getText().toString();
                message2 = editTextMessage.getText().toString();
            }
        });

        cancel = findViewById(R.id.cancelBtn);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cancelAlarm();
                cancelAlarm2();
            }
        });
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        Calendar startTime = Calendar.getInstance();
        startTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
        startTime.set(Calendar.MINUTE, minute);
        startTime.set(Calendar.SECOND, 0);

        updateTimeText(startTime);
        startAlarm(startTime);
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar startTime = Calendar.getInstance();
        startTime.set(Calendar.YEAR, year);
        startTime.set(Calendar.MONTH, month);
        startTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);

        updateDateText(startTime);
        startAlarm2(startTime);
    }

    private void updateTimeText(Calendar startTime) {
        String timeText = "Reminder set to: ";
        timeText += DateFormat.getTimeInstance(DateFormat.SHORT).format(startTime.getTime());
        mtextView.setText(timeText);
    }

    private void updateDateText(Calendar startTime) {
        String dateText = "Date set to: ";
        dateText += DateFormat.getDateInstance(DateFormat.FULL).format(startTime.getTime());
        textView.setText(dateText);
    }

    private void startAlarm(Calendar startTime) {
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent broadcastIntent = new Intent(this, alarmItems.class);
        PendingIntent actionIntent = PendingIntent.getBroadcast(this,
                1, broadcastIntent, 0);

        if (startTime.before(Calendar.getInstance())){
            startTime.add(Calendar.DATE, 1);
        }
        alarm.set(AlarmManager.RTC_WAKEUP, startTime.getTimeInMillis(), actionIntent);
    }

    private void startAlarm2(Calendar startTime) {
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent broadcastIntent = new Intent(this, dateItems.class);
        PendingIntent actionIntent = PendingIntent.getBroadcast(this,
                1, broadcastIntent, 0);

        if (startTime.before(Calendar.getInstance())){
            startTime.add(Calendar.DATE, 1);
        }
        alarm.set(AlarmManager.RTC_WAKEUP, startTime.getTimeInMillis(), actionIntent);
    }

    private void cancelAlarm() {
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent broadcastIntent = new Intent(this, alarmItems.class);
        PendingIntent actionIntent = PendingIntent.getBroadcast(this,
                1, broadcastIntent, 0);
        alarm.cancel(actionIntent);
        mtextView.setText("Reminder Canceled");
    }

    private void cancelAlarm2() {
        AlarmManager alarm = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent broadcastIntent = new Intent(this, dateItems.class);
        PendingIntent actionIntent = PendingIntent.getBroadcast(this,
                1, broadcastIntent, 0);
        alarm.cancel(actionIntent);
        textView.setText("Reminder Canceled");
    }
}

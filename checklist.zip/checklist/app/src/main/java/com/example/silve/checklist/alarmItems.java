package com.example.silve.checklist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import static com.example.silve.checklist.SetReminder.message;
import static com.example.silve.checklist.SetReminder.title;

public class alarmItems extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationHelper notificationHelper = new NotificationHelper(context);
        NotificationCompat.Builder builder = notificationHelper.getChannelNotification(title, message);
        notificationHelper.getManager().notify(0, builder.build());
    }
}

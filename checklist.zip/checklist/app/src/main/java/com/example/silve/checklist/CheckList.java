package com.example.silve.checklist;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class CheckList extends AppCompatActivity {

    public SharedPreferences preferences;
    public SharedPreferences.Editor editor;
    public Button addButton;
    public Button editButton;
    public EditText itemText;
    public ListView listItem;
    public ArrayList<Item> listing = new ArrayList<Item>();
    public MyCustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_list);

        preferences = getSharedPreferences("CheckList Pref", Context.MODE_PRIVATE);
        editor = preferences.edit();

        addButton = findViewById(R.id.adding);
        editButton = findViewById(R.id.editing);
        itemText = findViewById(R.id.editText);
        listItem = findViewById(R.id.itemListing);

        adapter = new MyCustomAdapter(this, R.layout.item, listing);
        listItem.setAdapter(adapter);

    }

    public void add(View view) {
        String text = itemText.getText().toString();
        Item addItem = new Item(text, false);
        listing.add(addItem);

        //code to add to sharedpref here


        //Toast.makeText(this, "item" + listing.get(0), Toast.LENGTH_LONG).show();
        adapter = new MyCustomAdapter(this, R.layout.item, listing);
        listItem.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void update(ArrayList<Item> listing) {
        this.listing = listing;
        adapter = new MyCustomAdapter(this, R.layout.item, listing);
        listItem.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    public void set(View view) {
        Intent intent = new Intent(this, SetReminder.class);
        startActivity(intent);
    }

    private class MyCustomAdapter extends ArrayAdapter<Item> {

        private ArrayList<Item> listing;

        MyCustomAdapter(Context context, int itemID, ArrayList<Item> listing) {
            super(context, itemID, listing);
            this.listing = new ArrayList<Item>();
            this.listing.addAll(listing);
        }

        private class ViewHolder {
            CheckBox checkBox;
            Button deleteButton;
        }

        @Override
        public View getView(final int position, View view, ViewGroup viewGroup) {
            //Toast.makeText(getContext(), "here ", Toast.LENGTH_LONG).show();
            ViewHolder holder = null;

            if(view  == null) {
                LayoutInflater vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                view = vi.inflate(R.layout.item, null);

                holder = new ViewHolder();

                holder.checkBox = (CheckBox) view.findViewById(R.id.check);
                holder.deleteButton = (Button) view.findViewById(R.id.button);
                view.setTag(holder);
            } else {
                holder = (ViewHolder) view.getTag();
            }
            Item item = listing.get(position);

            holder.checkBox.setText(item.getItem());
            holder.checkBox.setChecked(item.isSelect());
            holder.checkBox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CheckBox check = (CheckBox) v;
                    Item item = (Item) check.getTag();
                    boolean checked = item.isSelect();
                    item.setSelect(!checked);

                    //code to change the value in the sharedpref here
                    //value being false to true or true to false
                }
            });

            holder.deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //Item item = listItem.get(position);
                    listing.remove(position);

                    //code to remove a sharedpref here

                    update(listing);
                }
            });
            holder.deleteButton.setTag(item);
            holder.checkBox.setTag(item);
            return view;
        }
    }
}


package com.example.silve.checklist;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;

import static com.example.silve.checklist.SetReminder.message2;
import static com.example.silve.checklist.SetReminder.title2;

public class dateItems extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        DateNotificationHelper dNotificationHelper = new DateNotificationHelper(context);
        NotificationCompat.Builder builder = dNotificationHelper.getChannel2Notification(title2, message2);
        dNotificationHelper.getManager().notify(0, builder.build());
    }
}

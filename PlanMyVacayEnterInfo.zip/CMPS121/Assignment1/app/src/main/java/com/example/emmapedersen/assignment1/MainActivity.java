package com.example.emmapedersen.assignment1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //enter info button
    public void navigateOne(View view) {
        Intent intent = new Intent(this, EnterInfoActivity.class);
        startActivity(intent);
    }
    //view button
    public void navigateTwo(View view) {
        Intent intent = new Intent(this, ViewActivity.class);



        startActivity(intent);
    }
    //exit button
    public void navigateThree(View view) {
        finish();
    }
}

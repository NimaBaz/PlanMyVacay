package com.example.emmapedersen.assignment1;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ViewActivity extends AppCompatActivity {
    public static final String PREFS_NAME = "My Data";
    private String text1; //name
    private String text2;
    private String text3;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        listView = (ListView) findViewById(R.id.listview);
        //getting the data
        SharedPreferences data = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        text1 = data.getString("Name", "");
        text2 = data.getString("Year", "");
        text3 = data.getString("Photographer", "");

        //making the array
        java.util.List<String> array = new ArrayList<String>();
        array.add(text1);
        array.add(text2);
        array.add(text3);

        //array adapter
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, array);

        listView.setAdapter(arrayAdapter);

    }
}

package com.example.emmapedersen.assignment1;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;

public class EnterInfoActivity extends AppCompatActivity {
    private android.widget.Spinner spinner;
    private static final String[] years = {"2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011",
    "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997",
    "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988"};

    android.widget.EditText editText1; //name
    android.widget.EditText editText2; //photographer
    public static final String PREFS_NAME = "My Data";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_info);

        editText1 = findViewById(R.id.editText1);
        editText2 = findViewById(R.id.editText2);

        spinner = findViewById(R.id.spinner);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, years);
        spinner.setAdapter(adapter);


    }
    //done button
    public void navigateFour(View view) {
        Intent intent = new Intent(this, MainActivity.class);

        String name = editText1.getText().toString();
        String photographer = editText2.getText().toString();
        //spinner
        String year = spinner.getSelectedItem().toString();

        //saving the data to Shared Preferences
        SharedPreferences data = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = data.edit();
        editor.putString("Name", name);
        editor.putString("Year", year);
        editor.putString("Photographer", photographer);
        editor.apply();
        startActivity(intent);
    }

}

package com.example.planmyvacay;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListAdapter;

import java.util.ArrayList;


public class MyCustomAdapter extends BaseAdapter implements ListAdapter {
    private ArrayList<String> listRow = new ArrayList<String>();
    private Context context;

    public MyCustomAdapter(ArrayList<String> listRow, Context context){
        this.listRow = listRow;
        this.context = context;
    }
    @Override
    public int getCount() {
        return listRow.size();
    }

    @Override
    public Object getItem(int i) {
        return listRow.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    //Add more button, checkbox, or textbox here and the action with those added button, etc.
    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.simplerow, null);
        }

        //Getting the ID
        CheckBox checkBox = (CheckBox) view.findViewById(R.id.itemList);
        checkBox.setText(listRow.get(i));

        Button delete = (Button) view.findViewById(R.id.deleteButton);

        //Get the row to delete from the ListView and internal storage
        //i = position
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = listRow.get(i);
                context.deleteFile(text);
                listRow.remove(i);
                notifyDataSetChanged();
            }
        });
        return view;
    }
}
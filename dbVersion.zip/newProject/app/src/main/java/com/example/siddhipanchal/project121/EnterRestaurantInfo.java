package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class EnterRestaurantInfo extends AppCompatActivity {

    EditText rest;
    EditText addr;
    ListView restList;
    ArrayList<String> stringList;
    RestaurantAdapter listAdapter;
    File directory;
    String path;
    FileWriter outfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_restaurant_info);
        getSupportActionBar().hide();

        rest = findViewById(R.id.restaurant);
        addr = findViewById(R.id.address);
        restList = findViewById(R.id.listView);
        stringList = new ArrayList<String>();
        listAdapter = new RestaurantAdapter(stringList, this);

        directory = new File(String.valueOf(getFilesDir()) + "/Restaurant");
        if (!directory.exists()) {
            directory.mkdir();
        }
        path = String.valueOf(getFilesDir()) + "/Restaurant/";

        restList.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }

    public void add(View view) {
        String restString = rest.getText().toString();
        String addString = addr.getText().toString();

        try {
            outfile = new FileWriter(path + restString);
            outfile.write(restString + "\n");
            outfile.write(addString + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outfile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        stringList.add(restString);
        //restList.setAdapter(listAdapter);
        stringList.add(addString);
        restList.setAdapter(listAdapter);

        finish();
    }
}

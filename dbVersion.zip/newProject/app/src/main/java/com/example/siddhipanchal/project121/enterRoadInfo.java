package com.example.siddhipanchal.project121;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class enterRoadInfo extends AppCompatActivity {
    EditText location;
    EditText depTime;
    EditText miles;
    EditText wait1;
    EditText wait2;
    EditText wait3;
    EditText otherInfo;
    File folder;
    String path;
    FileWriter outFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_road_info);
        getSupportActionBar().hide();

        location = findViewById(R.id.destination);
        depTime = findViewById(R.id.departureTime);
        miles = findViewById(R.id.milePerDay);
        wait1 = findViewById(R.id.stop1);
        wait2 = findViewById(R.id.stop2);
        wait3 = findViewById(R.id.stop3);
        otherInfo = findViewById(R.id.other1);

        folder = new File(String.valueOf(getFilesDir()) + "/Road Trip");
        if (!folder.exists()) {
            folder.mkdir();
        }
        path = String.valueOf(getFilesDir()) +  "/Road Trip/";
    }


    public void done(View view) {
        String dest = location.getText().toString();
        String estimatedDep = depTime.getText().toString();
        String mi = miles.getText().toString();
        String restArea1 = wait1.getText().toString();
        String restArea2 = wait2.getText().toString();
        String restArea3 = wait3.getText().toString();
        String other = otherInfo.getText().toString();

        try {
            outFile =  new FileWriter(path + dest);
            outFile.write(dest + "\n");
            outFile.write(estimatedDep + "\n");
            outFile.write(mi + "\n");
            outFile.write(restArea1 + "\n");
            outFile.write(restArea2 + "\n");
            outFile.write(restArea3 + "\n");
            outFile.write(other + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            outFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finish();
    }
}

package com.example.siddhipanchal.project121;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class MyDB extends SQLiteOpenHelper {
    Context ctx;
    SQLiteDatabase db;
    private static String DB_NAME = "pmv";
    private static String TABLE_NAME = "tripInfo";

    private static int VERSION = 1;

    public MyDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version){
        super(context, DB_NAME, null, VERSION);
        ctx = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + TABLE_NAME + "(id integer primary key, " + "trip_name TEXT, flight_num TEXT); ");
        Toast.makeText(ctx, "DB is created", Toast.LENGTH_LONG);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists " + TABLE_NAME);
        VERSION++;
        onCreate(db);
    }

    public long insert(String s1){
        db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("trip_name", s1);
        return db.insert(TABLE_NAME, null, cv);
    }

    public Cursor getAll(){
        db = getReadableDatabase();
        Cursor cr = db.rawQuery("select * from " + TABLE_NAME + ";", null);
        StringBuilder sr = new StringBuilder();
        while(cr.moveToNext()){
            sr.append(cr.getString(1) + "   " + cr.getString(2) + "\n ");
        }
        Toast.makeText(ctx, sr.toString(), Toast.LENGTH_LONG).show();
        return cr;
    }

    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = String.format("Select * from %s", TABLE_NAME);
        Cursor data = db.rawQuery(query, null);
        return data;
    }
}

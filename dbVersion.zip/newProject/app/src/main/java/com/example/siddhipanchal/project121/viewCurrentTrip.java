package com.example.siddhipanchal.project121;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;


public class viewCurrentTrip extends AppCompatActivity{


    //public ListView info;
    public MyCustomAdapter listInfoAdapter;
    public ListView info;

    public FileWriter infoFile;
    public File infodirectory;

    public static java.util.List<String> list = new ArrayList<String>();
    ArrayAdapter adapter;


    MyDB db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_current_trip);
        getSupportActionBar().hide();

        info = (ListView) findViewById(R.id.info);
        db = new MyDB(this, "pmv", null, 1);
        //viewTrip();
        makeTextAppear();
    }

    public void goToChecklist(View view) {
        Intent intent = new Intent(this, CheckList.class);
        startActivity(intent);
    }

    private void makeTextAppear(){
        Cursor data = db.getData();
        ArrayList<String> listData = new ArrayList<>();
        while(data.moveToNext()){
            listData.add(data.getString(1));
        }
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        info.setAdapter(adapter);
    }
}